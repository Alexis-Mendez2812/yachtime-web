

/*$(document).ready(function(){


	$("#membership-join-button").click(function() {
	    $([document.documentElement, document.body]).animate({
	        scrollTop: $("#membershipPlans").offset().top
	    }, 2000);
	});

	$("#membership-join-button-main").click(function() {
		location.href = "/home/membership";
	});



	$('.burger, .overlay').click(function(){
	  $('.burger').toggleClass('clicked');
	  $('.overlay').toggleClass('show');
	  $('nav').toggleClass('show');
	  $('body').toggleClass('overflow');
	});


	$('.close').click(function(){
	  $('.burger').toggleClass('clicked');
	  $('.overlay').toggleClass('show');
	  $('nav').toggleClass('show');
	  $('body').toggleClass('overflow');
	});

});*/


